from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
import json
import csv
import matplotlib
matplotlib.use('Agg')  # Ensure matplotlib does not use any Xwindows backend
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from io import BytesIO
import base64
import os

app = Flask(__name__)

# Configuration
app.secret_key = 'your_secret_key'
UPLOAD_FOLDER = 'uploads'  # Ensure this directory exists
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB upload limit

# Ensure the UPLOAD_FOLDER exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def result():
    if 'csv_file' not in request.files:
        flash('No file part')
        return redirect(request.url)
    file = request.files['csv_file']
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)
    if file:
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        charts = process_file(filepath)
        
        # Pass the charts dictionary directly to the template
        return render_template('result.html', **charts)

def process_file(filepath):
    # Define paths to your JSON files for each category
    json_files = {
        'remember': 'C:\\Users\\Vrushabh\\Desktop\\ocr to blooms\\bloomstaxonomy\\remember.json',
        'understand': 'C:\\Users\\Vrushabh\\Desktop\\ocr to blooms\\bloomstaxonomy\\understand.json',
        'apply': 'C:\\Users\\Vrushabh\\Desktop\\ocr to blooms\\bloomstaxonomy\\apply.json',
        'analyzing': 'C:\\Users\\Vrushabh\\Desktop\\ocr to blooms\\bloomstaxonomy\\analyzing.json',
        'evaluation': 'C:\\Users\\Vrushabh\\Desktop\\ocr to blooms\\bloomstaxonomy\\evaluation.json',
        'creating': 'C:\\Users\\Vrushabh\\Desktop\\ocr to blooms\\bloomstaxonomy\\creating.json'
    }
    scores = {}
    keyword_matches = {}
    
    # Process each category
    for category, json_file_path in json_files.items():
        with open(json_file_path) as f:
            criteria = json.load(f)
            score, matches = calculate_score(criteria, filepath)
            scores[category] = score
            keyword_matches[category] = matches

    # Generate and encode charts for each category
    charts = {f"{category}_img_str": generate_encoded_chart(matches, category.capitalize()) 
              for category, matches in keyword_matches.items()}
    
    # Generate and encode the scores bar chart
    charts['score_bar_chart'] = generate_bar_chart(scores, "Scores")

    return charts

def calculate_score(criteria, csv_filename):
    with open(csv_filename, 'r') as csv_file:
        reader = csv.reader(csv_file)
        words = [word for row in reader for word in row]
    keyword_matches = len(set(words) & set(criteria["keywords"]))
    keyword_marks_percentage = (keyword_matches / len(criteria["keywords"])) * 100
    return keyword_marks_percentage, keyword_matches

def generate_encoded_chart(matches, analysis_type):
    fig, ax = plt.subplots()
    labels = [f'Matched {analysis_type} Keywords', f'Remaining']
    sizes = [matches, 100 - matches]
    colors = ['#4caf50', '#ffcccb']
    ax.pie(sizes, labels=labels, startangle=90, autopct='%1.1f%%', colors=colors)
    ax.axis('equal')
    
    pngImage = BytesIO()
    FigureCanvas(fig).print_png(pngImage)
    plt.close(fig)  # Important to prevent memory leak
    
    return f"data:image/png;base64,{base64.b64encode(pngImage.getvalue()).decode('utf8')}"

def generate_bar_chart(scores, title):
    fig, ax = plt.subplots()
    categories = list(scores.keys())
    values = list(scores.values())
    ax.bar(categories, values, color=['#4caf50', '#5599ff'])
    ax.set_ylabel('Scores')
    ax.set_title(title)
    
    pngImage = BytesIO()
    FigureCanvas(fig).print_png(pngImage)
    plt.close(fig)  # Important to prevent memory leak
    
    return f"data:image/png;base64,{base64.b64encode(pngImage.getvalue()).decode('utf8')}"

if __name__ == "__main__":
    app.run(debug=True)
